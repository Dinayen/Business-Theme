<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'business');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '4+M3. Lp2HP}SE)G6A> 8u[Mh7nv e $Z}/#Cp7Q$DN^_L]29M:>9xGX]:sN#iH!');
define('SECURE_AUTH_KEY',  '[RDfoj;}cH2S_G7?Yk{>x-_8H2$={jWZF?HtUB5<2l)55k=E~@RGWC?>GC^8&|O#');
define('LOGGED_IN_KEY',    'LR!@S7.zZ;y@SHJ:TAU||d0,B@Ka7cEG{a->/]/8a/V2j~)aB.2&oMrw1WtSz+zp');
define('NONCE_KEY',        ' ^Xibw:zAn)d)*PxZ jj,Z,)Pu3i<TFcWwY`%$vjwiS<o!:sj@(F!wb-9%};%s^{');
define('AUTH_SALT',        'Xp&)0(R*7foJG)8![{^[ @:P~U4:QT6Oj|jmd~S8r YFui}SNA@3)09/h+6sc|V=');
define('SECURE_AUTH_SALT', 'Ljh%uNc18y&w4o$0>i59HJzqwcE7mnrcI~&9{BzubEbYir(mv7h`j%&N@62;&~@|');
define('LOGGED_IN_SALT',   'yC9RH}xmB<27?==Z?>@qgt-K<Jx-UzM`5;]S}dMqy,on.Okc>;-^_YB7H+x-h:Y4');
define('NONCE_SALT',       'QYrSX%|O$4CYthA|s0j+yxGCf(}}F8 dE} +e]yeOfI+I%RzUU@x5~E=e*+,p.47');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
