-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2019 at 04:09 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `business`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-08-14 14:36:15', '2019-08-14 14:36:15', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0),
(2, 24, 'Stephanie', 'dinayenstephanie047@gmail.com', '', '::1', '2019-08-16 10:12:15', '2019-08-16 10:12:15', 'this a very nice php  framework', 0, '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '', 0, 1),
(3, 70, 'Dinayen', 'stacys@gmail.com', '', '::1', '2019-08-16 11:14:34', '2019-08-16 11:14:34', 'The rate  of unemployment in our country is alarming, but from my own point of view youths of now our days are not doing anything to help the state in eradicating the high rate of umemployment', 0, '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '', 0, 0),
(4, 30, 'victor', 'stacys@gmail.com', '', '::1', '2019-08-16 12:00:02', '2019-08-16 12:00:02', 'bsdfjbsdfndvf', 0, '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/Business', 'yes'),
(2, 'home', 'http://localhost/Business', 'yes'),
(3, 'blogname', 'Business Theme', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'dinayenstephanie047@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:90:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=13&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:0:{}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'Business', 'yes'),
(41, 'stylesheet', 'Business', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:3;a:4:{s:5:\"title\";s:10:\"Categories\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '17', 'yes'),
(84, 'page_on_front', '13', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '38590', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:2:{i:3;a:3:{s:5:\"title\";s:11:\"Recent Post\";s:6:\"number\";i:5;s:9:\"show_date\";b:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:2:{i:3;a:2:{s:5:\"title\";s:15:\"Recent Comments\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:12:{s:19:\"wp_inactive_widgets\";a:0:{}s:16:\"content-region-1\";a:1:{i:0;s:13:\"custom_html-4\";}s:16:\"content-region-2\";a:1:{i:0;s:13:\"custom_html-5\";}s:22:\"content-region-2-image\";a:1:{i:0;s:13:\"media_image-2\";}s:8:\"footer-1\";a:1:{i:0;s:13:\"custom_html-3\";}s:8:\"footer-2\";a:1:{i:0;s:13:\"custom_html-2\";}s:8:\"footer-3\";a:1:{i:0;s:7:\"pages-2\";}s:7:\"sidebar\";a:3:{i:0;s:14:\"recent-posts-3\";i:1;s:12:\"categories-3\";i:2;s:17:\"recent-comments-3\";}s:8:\"our-team\";a:2:{i:0;s:13:\"media_image-4\";i:1;s:13:\"custom_html-7\";}s:12:\"our-projects\";a:2:{i:0;s:13:\"media_image-3\";i:1;s:13:\"custom_html-6\";}s:12:\"contact-page\";a:1:{i:0;s:13:\"custom_html-9\";}s:13:\"array_version\";i:3;}', 'yes'),
(102, 'widget_pages', 'a:2:{i:2;a:3:{s:5:\"title\";s:5:\"Pages\";s:6:\"sortby\";s:10:\"menu_order\";s:7:\"exclude\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:4:{i:2;a:15:{s:13:\"attachment_id\";i:22;s:3:\"url\";s:89:\"http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-III039-300x170.jpg\";s:5:\"title\";s:0:\"\";s:4:\"size\";s:6:\"medium\";s:5:\"width\";i:600;s:6:\"height\";i:340;s:7:\"caption\";s:0:\"\";s:3:\"alt\";s:0:\"\";s:9:\"link_type\";s:6:\"custom\";s:8:\"link_url\";s:0:\"\";s:13:\"image_classes\";s:0:\"\";s:12:\"link_classes\";s:0:\"\";s:8:\"link_rel\";s:0:\"\";s:17:\"link_target_blank\";b:0;s:11:\"image_title\";s:0:\"\";}i:3;a:15:{s:13:\"attachment_id\";i:42;s:3:\"url\";s:90:\"http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-II124-1-300x170.jpg\";s:5:\"title\";s:12:\"OUR PROJECTS\";s:4:\"size\";s:6:\"medium\";s:5:\"width\";i:600;s:6:\"height\";i:340;s:7:\"caption\";s:58:\"Large business group gathering to discuss business matters\";s:3:\"alt\";s:0:\"\";s:9:\"link_type\";s:6:\"custom\";s:8:\"link_url\";s:0:\"\";s:13:\"image_classes\";s:0:\"\";s:12:\"link_classes\";s:0:\"\";s:8:\"link_rel\";s:0:\"\";s:17:\"link_target_blank\";b:0;s:11:\"image_title\";s:0:\"\";}i:4;a:15:{s:13:\"attachment_id\";i:43;s:3:\"url\";s:91:\"http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-III089-1-300x170.jpg\";s:5:\"title\";s:8:\"OUR TEAM\";s:4:\"size\";s:6:\"medium\";s:5:\"width\";i:600;s:6:\"height\";i:340;s:7:\"caption\";s:74:\"Two young beautiful girls are walking through the city and listen to music\";s:3:\"alt\";s:0:\"\";s:9:\"link_type\";s:6:\"custom\";s:8:\"link_url\";s:0:\"\";s:13:\"image_classes\";s:0:\"\";s:12:\"link_classes\";s:0:\"\";s:8:\"link_rel\";s:0:\"\";s:17:\"link_target_blank\";b:0;s:11:\"image_title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:8:{i:2;a:2:{s:5:\"title\";s:13:\"Conatact Form\";s:7:\"content\";s:303:\"<form action=\"\">\r\n                        <input type=\"text\" name=\"\" id=\"\" placeholder=\"Enter Name\"><br>\r\n                        <input type=\"text\" name=\"\" id=\"\" placeholder=\"Email Address\"><br>\r\n                        <input type=\"submit\" class=\"btn-footer\" value=\"SEND\">\r\n                    </form>\";}i:3;a:2:{s:5:\"title\";s:0:\"\";s:7:\"content\";s:235:\"<h4>Heading</h4>\r\n                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laudantium earum quae sint \r\n                        voluptate amet deleniti libero deserunt a in dolor explicabo est enim, quod at.</p>\";}i:4;a:2:{s:5:\"title\";s:20:\"Bootstrap Lead Class\";s:7:\"content\";s:236:\"<p class=\"lead\">\r\n	Lorem ipsum dolor sit, amet consectetur adipisicing elit. Explicabo aperiam ullam cum eos molestias aliquam in officiis alias nisi atque? Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione, vitae!\r\n</p>\";}i:5;a:2:{s:5:\"title\";s:14:\"Theme Features\";s:7:\"content\";s:534:\"                    <ul class=\"list-group\">\r\n                        <li class=\"list-group-item\"><i class=\"fa fa-check\" aria-hidden=\"true\">Codeigniter</i></li>\r\n                        <li class=\"list-group-item\"><i class=\"fa fa-check\" aria-hidden=\"true\">Codeigniter</i></li>\r\n                        <li class=\"list-group-item\"><i class=\"fa fa-check\" aria-hidden=\"true\">Codeigniter</i></li>\r\n                        <li class=\"list-group-item\"><i class=\"fa fa-check\" aria-hidden=\"true\">Codeigniter</i></li>\r\n                    </ul>\";}i:6;a:2:{s:5:\"title\";s:0:\"\";s:7:\"content\";s:219:\"Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\";}i:7;a:2:{s:5:\"title\";s:0:\"\";s:7:\"content\";s:217:\"Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\";}i:9;a:2:{s:5:\"title\";s:0:\"\";s:7:\"content\";s:911:\"<div class=\"container\">\r\n            <div class=\"row\">\r\n              \r\n               \r\n                <a href=\"#\" class=\"white-text\">\r\n                    <i class=\"fab fa-facebook fa-4x\"></i>\r\n                </a>\r\n                <a href=\"#\" class=\"white-text\">\r\n                        <i class=\"fab fa-google-plus fa-4x\"></i>\r\n                </a>\r\n                <a href=\"#\" class=\"white-text\">\r\n                    <i class=\"fab fa-linkedin fa-4x\"></i>\r\n                </a>\r\n                <a href=\"#\" class=\"white-text\">\r\n                    <i class=\"fab fa-twitter fa-4x\"></i>\r\n                </a>\r\n                <a href=\"#\" class=\"white-text\">\r\n                    <i class=\"fab fa-instagram fa-4x\"></i>\r\n                </a>\r\n                <a href=\"#\" class=\"white-text\">\r\n                    <i class=\"fab fa-pinterest fa-4x\"></i>\r\n                </a>\r\n            </div>\r\n        </div>\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'cron', 'a:5:{i:1565966178;a:2:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1565966179;a:2:{s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1565966198;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1566031593;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(112, 'theme_mods_twentyseventeen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1565793843;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(116, '_site_transient_update_core', 'O:8:\"stdClass\":3:{s:7:\"updates\";a:0:{}s:15:\"version_checked\";s:5:\"4.9.8\";s:12:\"last_checked\";i:1565945021;}', 'no'),
(117, '_site_transient_update_plugins', 'O:8:\"stdClass\":1:{s:12:\"last_checked\";i:1565945022;}', 'no'),
(120, '_site_transient_update_themes', 'O:8:\"stdClass\":1:{s:12:\"last_checked\";i:1565945023;}', 'no'),
(124, 'can_compress_scripts', '1', 'no'),
(125, 'current_theme', 'Business Theme', 'yes'),
(126, 'theme_mods_Business', 'a:13:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:9:\"box1_text\";s:211:\"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Explicabo aperiam ullam cum eos molestias aliquam in officiis alias nisi atque? Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione, vitae!\";s:9:\"box1_icon\";s:3:\"pen\";s:9:\"box2_text\";s:211:\"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Explicabo aperiam ullam cum eos molestias aliquam in officiis alias nisi atque? Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione, vitae!\";s:9:\"box2_icon\";s:6:\"laptop\";s:9:\"box3_text\";s:211:\"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Explicabo aperiam ullam cum eos molestias aliquam in officiis alias nisi atque? Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione, vitae!\";s:12:\"box1_heading\";s:9:\"Education\";s:12:\"box2_heading\";s:14:\"Laptop Repairs\";s:12:\"box3_heading\";s:21:\"Computer Maintainance\";s:14:\"banner_heading\";s:8:\"Business\";s:12:\"banner_image\";s:72:\"http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-6D048.jpg\";}', 'yes'),
(127, 'theme_switched', '', 'yes'),
(129, '_site_transient_timeout_theme_roots', '1565946823', 'no'),
(130, '_site_transient_theme_roots', 'a:4:{s:8:\"Business\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}', 'no'),
(133, 'nav_menu_options', 'a:1:{s:8:\"auto_add\";a:0:{}}', 'yes'),
(153, 'category_children', 'a:0:{}', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_menu_item_type', 'custom'),
(4, 5, '_menu_item_menu_item_parent', '0'),
(5, 5, '_menu_item_object_id', '5'),
(6, 5, '_menu_item_object', 'custom'),
(7, 5, '_menu_item_target', ''),
(8, 5, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(9, 5, '_menu_item_xfn', ''),
(10, 5, '_menu_item_url', 'http://localhost/Business/'),
(11, 5, '_menu_item_orphaned', '1565945070'),
(12, 6, '_menu_item_type', 'post_type'),
(13, 6, '_menu_item_menu_item_parent', '0'),
(14, 6, '_menu_item_object_id', '2'),
(15, 6, '_menu_item_object', 'page'),
(16, 6, '_menu_item_target', ''),
(17, 6, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(18, 6, '_menu_item_xfn', ''),
(19, 6, '_menu_item_url', ''),
(20, 6, '_menu_item_orphaned', '1565945070'),
(21, 7, '_menu_item_type', 'custom'),
(22, 7, '_menu_item_menu_item_parent', '0'),
(23, 7, '_menu_item_object_id', '7'),
(24, 7, '_menu_item_object', 'custom'),
(25, 7, '_menu_item_target', ''),
(26, 7, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(27, 7, '_menu_item_xfn', ''),
(28, 7, '_menu_item_url', 'http://localhost/Business/'),
(29, 7, '_menu_item_orphaned', '1565945089'),
(30, 8, '_menu_item_type', 'post_type'),
(31, 8, '_menu_item_menu_item_parent', '0'),
(32, 8, '_menu_item_object_id', '2'),
(33, 8, '_menu_item_object', 'page'),
(34, 8, '_menu_item_target', ''),
(35, 8, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(36, 8, '_menu_item_xfn', ''),
(37, 8, '_menu_item_url', ''),
(38, 8, '_menu_item_orphaned', '1565945089'),
(39, 10, '_menu_item_type', 'custom'),
(40, 10, '_menu_item_menu_item_parent', '0'),
(41, 10, '_menu_item_object_id', '10'),
(42, 10, '_menu_item_object', 'custom'),
(43, 10, '_menu_item_target', ''),
(44, 10, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(45, 10, '_menu_item_xfn', ''),
(46, 10, '_menu_item_url', 'http://localhost/Business'),
(47, 9, '_wp_trash_meta_status', 'publish'),
(48, 9, '_wp_trash_meta_time', '1565945146'),
(49, 2, '_wp_trash_meta_status', 'publish'),
(50, 2, '_wp_trash_meta_time', '1565945186'),
(51, 2, '_wp_desired_post_slug', 'sample-page'),
(52, 3, '_wp_trash_meta_status', 'draft'),
(53, 3, '_wp_trash_meta_time', '1565945190'),
(54, 3, '_wp_desired_post_slug', 'privacy-policy'),
(55, 13, '_edit_last', '1'),
(56, 13, '_edit_lock', '1565945061:1'),
(57, 15, '_edit_last', '1'),
(58, 15, '_edit_lock', '1565947202:1'),
(59, 17, '_edit_last', '1'),
(60, 17, '_edit_lock', '1565945082:1'),
(61, 19, '_menu_item_type', 'post_type'),
(62, 19, '_menu_item_menu_item_parent', '0'),
(63, 19, '_menu_item_object_id', '17'),
(64, 19, '_menu_item_object', 'page'),
(65, 19, '_menu_item_target', ''),
(66, 19, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(67, 19, '_menu_item_xfn', ''),
(68, 19, '_menu_item_url', ''),
(70, 20, '_menu_item_type', 'post_type'),
(71, 20, '_menu_item_menu_item_parent', '0'),
(72, 20, '_menu_item_object_id', '15'),
(73, 20, '_menu_item_object', 'page'),
(74, 20, '_menu_item_target', ''),
(75, 20, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(76, 20, '_menu_item_xfn', ''),
(77, 20, '_menu_item_url', ''),
(79, 21, '_menu_item_type', 'post_type'),
(80, 21, '_menu_item_menu_item_parent', '0'),
(81, 21, '_menu_item_object_id', '13'),
(82, 21, '_menu_item_object', 'page'),
(83, 21, '_menu_item_target', ''),
(84, 21, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(85, 21, '_menu_item_xfn', ''),
(86, 21, '_menu_item_url', ''),
(87, 21, '_menu_item_orphaned', '1565945243'),
(88, 22, '_wp_attached_file', '2019/08/Canon-EOS-5D-Mark-III039.jpg'),
(89, 22, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:36:\"2019/08/Canon-EOS-5D-Mark-III039.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III039-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III039-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III039-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:2:\"11\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:21:\"Canon EOS 5D Mark III\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"265\";s:3:\"iso\";s:4:\"1600\";s:13:\"shutter_speed\";s:17:\"0.016666666666667\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(90, 1, '_wp_trash_meta_status', 'publish'),
(91, 1, '_wp_trash_meta_time', '1565946273'),
(92, 1, '_wp_desired_post_slug', 'hello-world'),
(93, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:\"1\";}'),
(94, 24, '_edit_last', '1'),
(95, 24, '_edit_lock', '1565946305:1'),
(96, 25, '_wp_attached_file', '2019/08/Canon-EOS-5D-Mark-III101.jpg'),
(97, 25, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:36:\"2019/08/Canon-EOS-5D-Mark-III101.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III101-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III101-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III101-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"3.2\";s:6:\"credit\";s:16:\"ViktorHanacek.cz\";s:6:\"camera\";s:21:\"Canon EOS 5D Mark III\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1422015050\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"28\";s:3:\"iso\";s:3:\"640\";s:13:\"shutter_speed\";s:17:\"0.016666666666667\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(98, 24, '_thumbnail_id', '25'),
(103, 27, '_edit_last', '1'),
(104, 27, '_edit_lock', '1565946364:1'),
(105, 28, '_wp_attached_file', '2019/08/Canon-EOS-5D-Mark-III169.jpg'),
(106, 28, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:36:\"2019/08/Canon-EOS-5D-Mark-III169.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III169-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III169-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III169-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:21:\"Canon EOS 5D Mark III\";s:7:\"caption\";s:64:\"Group of business partners discussing ideas at meeting in office\";s:17:\"created_timestamp\";s:10:\"1390892284\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:5:\"0.008\";s:5:\"title\";s:18:\"Working at meeting\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:50:{i:0;s:14:\"businesspeople\";i:1;s:6:\"people\";i:2;s:8:\"business\";i:3;s:5:\"group\";i:4;s:4:\"team\";i:5;s:7:\"meeting\";i:6;s:3:\"man\";i:7;s:6:\"female\";i:8;s:5:\"woman\";i:9;s:13:\"businesswoman\";i:10;s:6:\"person\";i:11;s:5:\"white\";i:12;s:7:\"partner\";i:13;s:5:\"young\";i:14;s:11:\"businessman\";i:15;s:9:\"confident\";i:16;s:12:\"professional\";i:17;s:3:\"job\";i:18;s:4:\"male\";i:19;s:12:\"contemporary\";i:20;s:9:\"corporate\";i:21;s:9:\"executive\";i:22;s:10:\"occupation\";i:23;s:9:\"associate\";i:24;s:5:\"adult\";i:25;s:9:\"colleague\";i:26;s:9:\"co-worker\";i:27;s:8:\"employee\";i:28;s:7:\"company\";i:29;s:6:\"collar\";i:30;s:6:\"worker\";i:31;s:10:\"employment\";i:32;s:10:\"discussing\";i:33;s:7:\"sharing\";i:34;s:4:\"idea\";i:35;s:9:\"attention\";i:36;s:8:\"planning\";i:37;s:8:\"strategy\";i:38;s:13:\"brainstorming\";i:39;s:9:\"ethnicity\";i:40;s:12:\"multi-ethnic\";i:41;s:9:\"Caucasian\";i:42;s:16:\"African-american\";i:43;s:8:\"briefing\";i:44;s:6:\"office\";i:45;s:12:\"conversation\";i:46;s:13:\"communicating\";i:47;s:9:\"listening\";i:48;s:6:\"pretty\";i:49;s:8:\"handsome\";}}}'),
(107, 27, '_thumbnail_id', '28'),
(110, 30, '_edit_last', '1'),
(111, 30, '_edit_lock', '1565946410:1'),
(112, 31, '_wp_attached_file', '2019/08/Canon-EOS-5D-Mark-III111.jpg'),
(113, 31, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:36:\"2019/08/Canon-EOS-5D-Mark-III111.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III111-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III111-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III111-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"3.2\";s:6:\"credit\";s:16:\"ViktorHanacek.cz\";s:6:\"camera\";s:21:\"Canon EOS 5D Mark III\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1442166920\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:3:\"320\";s:13:\"shutter_speed\";s:17:\"0.016666666666667\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(114, 30, '_thumbnail_id', '31'),
(117, 33, '_edit_last', '1'),
(118, 33, '_edit_lock', '1565946467:1'),
(119, 34, '_wp_attached_file', '2019/08/Canon-EOS-6D090.jpg'),
(120, 34, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:27:\"2019/08/Canon-EOS-6D090.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"Canon-EOS-6D090-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"Canon-EOS-6D090-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:27:\"Canon-EOS-6D090-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"3.5\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:12:\"Canon EOS 6D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"135\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:6:\"0.0125\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(121, 33, '_thumbnail_id', '34'),
(124, 36, '_edit_last', '1'),
(125, 36, '_edit_lock', '1565946634:1'),
(126, 37, '_wp_attached_file', '2019/08/Canon-EOS-5D-Mark-III089.jpg'),
(127, 37, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:36:\"2019/08/Canon-EOS-5D-Mark-III089.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III089-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III089-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III089-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"3.5\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:21:\"Canon EOS 5D Mark III\";s:7:\"caption\";s:74:\"Two young beautiful girls are walking through the city and listen to music\";s:17:\"created_timestamp\";s:10:\"1434206729\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"135\";s:3:\"iso\";s:3:\"640\";s:13:\"shutter_speed\";s:9:\"0.0015625\";s:5:\"title\";s:25:\"Two young beautiful girls\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:50:{i:0;s:3:\"hat\";i:1;s:5:\"music\";i:2;s:6:\"listen\";i:3;s:10:\"smartphone\";i:4;s:10:\"headphones\";i:5;s:3:\"bag\";i:6;s:9:\"beautiful\";i:7;s:8:\"brunette\";i:8;s:4:\"city\";i:9;s:6:\"couple\";i:10;s:5:\"dress\";i:11;s:7:\"fashion\";i:12;s:4:\"girl\";i:13;s:5:\"happy\";i:14;s:3:\"joy\";i:15;s:6:\"person\";i:16;s:8:\"portrait\";i:17;s:6:\"pretty\";i:18;s:3:\"fun\";i:19;s:6:\"street\";i:20;s:6:\"summer\";i:21;s:10:\"sunglasses\";i:22;s:3:\"two\";i:23;s:5:\"urban\";i:24;s:5:\"young\";i:25;s:5:\"adult\";i:26;s:6:\"beauty\";i:27;s:6:\"casual\";i:28;s:9:\"caucasian\";i:29;s:4:\"cute\";i:30;s:4:\"town\";i:31;s:7:\"outside\";i:32;s:4:\"blue\";i:33;s:7:\"walking\";i:34;s:8:\"cheerful\";i:35;s:7:\"outdoor\";i:36;s:7:\"relaxed\";i:37;s:9:\"enjoyment\";i:38;s:5:\"woman\";i:39;s:6:\"jacket\";i:40;s:8:\"emotions\";i:41;s:6:\"female\";i:42;s:5:\"black\";i:43;s:9:\"lifestyle\";i:44;s:7:\"smiling\";i:45;s:6:\"posing\";i:46;s:2:\"go\";i:47;s:8:\"outdoors\";i:48;s:6:\"friend\";i:49;s:11:\"girlfriends\";}}}'),
(128, 36, '_thumbnail_id', '37'),
(133, 40, '_wp_attached_file', '2019/08/Canon-EOS-5D-Mark-IV137-1.jpg'),
(134, 40, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:37:\"2019/08/Canon-EOS-5D-Mark-IV137-1.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"Canon-EOS-5D-Mark-IV137-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"Canon-EOS-5D-Mark-IV137-1-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:37:\"Canon-EOS-5D-Mark-IV137-1-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"8\";s:6:\"credit\";s:11:\"ZHANGWUXUAN\";s:6:\"camera\";s:20:\"Canon EOS 5D Mark IV\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1513954845\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"70\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:5:\"0.008\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(135, 15, '_thumbnail_id', '40'),
(136, 42, '_wp_attached_file', '2019/08/Canon-EOS-5D-Mark-II124-1.jpg'),
(137, 42, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:37:\"2019/08/Canon-EOS-5D-Mark-II124-1.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"Canon-EOS-5D-Mark-II124-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"Canon-EOS-5D-Mark-II124-1-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:37:\"Canon-EOS-5D-Mark-II124-1-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:20:\"Canon EOS 5D Mark II\";s:7:\"caption\";s:58:\"Large business group gathering to discuss business matters\";s:17:\"created_timestamp\";s:10:\"1337062679\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:7:\"0.00625\";s:5:\"title\";s:8:\"Teamwork\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:50:{i:0;s:6:\"people\";i:1;s:6:\"person\";i:2;s:9:\"lifestyle\";i:3;s:9:\"Caucasian\";i:4;s:3:\"man\";i:5;s:5:\"woman\";i:6;s:4:\"male\";i:7;s:6:\"female\";i:8;s:8:\"business\";i:9;s:11:\"businessman\";i:10;s:13:\"businesswoman\";i:11;s:4:\"team\";i:12;s:8:\"teamwork\";i:13;s:8:\"together\";i:14;s:8:\"gathered\";i:15;s:11:\"cooperation\";i:16;s:13:\"collaboration\";i:17;s:7:\"friends\";i:18;s:10:\"friendship\";i:19;s:5:\"group\";i:20;s:13:\"professionals\";i:21;s:6:\"modern\";i:22;s:6:\"laptop\";i:23;s:8:\"computer\";i:24;s:6:\"indoor\";i:25;s:6:\"office\";i:26;s:9:\"workplace\";i:27;s:6:\"seated\";i:28;s:7:\"sitting\";i:29;s:6:\"formal\";i:30;s:10:\"formalwear\";i:31;s:7:\"elegant\";i:32;s:9:\"corporate\";i:33;s:11:\"experienced\";i:34;s:12:\"white-collar\";i:35;s:7:\"workers\";i:36;s:12:\"well-dressed\";i:37;s:10:\"successful\";i:38;s:9:\"confident\";i:39;s:8:\"positive\";i:40;s:8:\"friendly\";i:41;s:7:\"smiling\";i:42;s:7:\"meeting\";i:43;s:10:\"discussing\";i:44;s:10:\"discussion\";i:45;s:13:\"brainstorming\";i:46;s:10:\"colleagues\";i:47;s:10:\"associates\";i:48;s:9:\"paperwork\";i:49;s:6:\"tablet\";}}}'),
(138, 43, '_wp_attached_file', '2019/08/Canon-EOS-5D-Mark-III089-1.jpg'),
(139, 43, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:38:\"2019/08/Canon-EOS-5D-Mark-III089-1.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:38:\"Canon-EOS-5D-Mark-III089-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:38:\"Canon-EOS-5D-Mark-III089-1-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:38:\"Canon-EOS-5D-Mark-III089-1-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"3.5\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:21:\"Canon EOS 5D Mark III\";s:7:\"caption\";s:74:\"Two young beautiful girls are walking through the city and listen to music\";s:17:\"created_timestamp\";s:10:\"1434206729\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"135\";s:3:\"iso\";s:3:\"640\";s:13:\"shutter_speed\";s:9:\"0.0015625\";s:5:\"title\";s:25:\"Two young beautiful girls\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:50:{i:0;s:3:\"hat\";i:1;s:5:\"music\";i:2;s:6:\"listen\";i:3;s:10:\"smartphone\";i:4;s:10:\"headphones\";i:5;s:3:\"bag\";i:6;s:9:\"beautiful\";i:7;s:8:\"brunette\";i:8;s:4:\"city\";i:9;s:6:\"couple\";i:10;s:5:\"dress\";i:11;s:7:\"fashion\";i:12;s:4:\"girl\";i:13;s:5:\"happy\";i:14;s:3:\"joy\";i:15;s:6:\"person\";i:16;s:8:\"portrait\";i:17;s:6:\"pretty\";i:18;s:3:\"fun\";i:19;s:6:\"street\";i:20;s:6:\"summer\";i:21;s:10:\"sunglasses\";i:22;s:3:\"two\";i:23;s:5:\"urban\";i:24;s:5:\"young\";i:25;s:5:\"adult\";i:26;s:6:\"beauty\";i:27;s:6:\"casual\";i:28;s:9:\"caucasian\";i:29;s:4:\"cute\";i:30;s:4:\"town\";i:31;s:7:\"outside\";i:32;s:4:\"blue\";i:33;s:7:\"walking\";i:34;s:8:\"cheerful\";i:35;s:7:\"outdoor\";i:36;s:7:\"relaxed\";i:37;s:9:\"enjoyment\";i:38;s:5:\"woman\";i:39;s:6:\"jacket\";i:40;s:8:\"emotions\";i:41;s:6:\"female\";i:42;s:5:\"black\";i:43;s:9:\"lifestyle\";i:44;s:7:\"smiling\";i:45;s:6:\"posing\";i:46;s:2:\"go\";i:47;s:8:\"outdoors\";i:48;s:6:\"friend\";i:49;s:11:\"girlfriends\";}}}'),
(140, 44, '_wp_attached_file', '2019/08/Canon-EOS-5D-Mark-III045-1.jpg'),
(141, 44, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:38:\"2019/08/Canon-EOS-5D-Mark-III045-1.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:38:\"Canon-EOS-5D-Mark-III045-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:38:\"Canon-EOS-5D-Mark-III045-1-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:38:\"Canon-EOS-5D-Mark-III045-1-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"1.4\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:21:\"Canon EOS 5D Mark III\";s:7:\"caption\";s:82:\"Portrait of young woman and her daughters sitting by dinner table and having meals\";s:17:\"created_timestamp\";s:10:\"1389949527\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:7:\"0.00625\";s:5:\"title\";s:13:\"Family dinner\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:50:{i:0;s:6:\"family\";i:1;s:6:\"person\";i:2;s:6:\"people\";i:3;s:6:\"female\";i:4;s:5:\"woman\";i:5;s:8:\"daughter\";i:6;s:4:\"girl\";i:7;s:5:\"child\";i:8;s:5:\"happy\";i:9;s:7:\"smiling\";i:10;s:5:\"adult\";i:11;s:5:\"young\";i:12;s:6:\"mother\";i:13;s:6:\"parent\";i:14;s:4:\"wife\";i:15;s:6:\"pretty\";i:16;s:4:\"home\";i:17;s:8:\"cheerful\";i:18;s:4:\"food\";i:19;s:9:\"nutrition\";i:20;s:7:\"holding\";i:21;s:7:\"kitchen\";i:22;s:7:\"cuisine\";i:23;s:9:\"Caucasian\";i:24;s:8:\"portrait\";i:25;s:6:\"indoor\";i:26;s:6:\"inside\";i:27;s:4:\"cute\";i:28;s:8:\"charming\";i:29;s:9:\"beautiful\";i:30;s:8:\"adorable\";i:31;s:5:\"pizza\";i:32;s:6:\"dinner\";i:33;s:4:\"meal\";i:34;s:7:\"gourmet\";i:35;s:8:\"together\";i:36;s:5:\"three\";i:37;s:5:\"group\";i:38;s:7:\"company\";i:39;s:8:\"teenager\";i:40;s:6:\"edible\";i:41;s:5:\"tasty\";i:42;s:9:\"delicious\";i:43;s:8:\"gathered\";i:44;s:5:\"drink\";i:45;s:5:\"juice\";i:46;s:7:\"pouring\";i:47;s:5:\"plate\";i:48;s:6:\"hungry\";i:49;s:8:\"beverage\";}}}'),
(142, 45, '_edit_last', '1'),
(143, 45, '_edit_lock', '1565948306:1'),
(144, 47, '_menu_item_type', 'post_type'),
(145, 47, '_menu_item_menu_item_parent', '0'),
(146, 47, '_menu_item_object_id', '45'),
(147, 47, '_menu_item_object', 'page'),
(148, 47, '_menu_item_target', ''),
(149, 47, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(150, 47, '_menu_item_xfn', ''),
(151, 47, '_menu_item_url', ''),
(153, 48, '_wp_attached_file', '2019/08/Canon-EOS-6D085-1.jpg'),
(154, 48, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:29:\"2019/08/Canon-EOS-6D085-1.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"Canon-EOS-6D085-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"Canon-EOS-6D085-1-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:29:\"Canon-EOS-6D085-1-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:2:\"14\";s:6:\"credit\";s:5:\"LzLai\";s:6:\"camera\";s:12:\"Canon EOS 6D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1500653264\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"100\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:7:\"0.00625\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(155, 45, '_thumbnail_id', '48'),
(156, 50, '_edit_last', '1'),
(157, 50, '_edit_lock', '1565948364:1'),
(158, 52, '_wp_attached_file', '2019/08/Canon-EOS-6D048.jpg'),
(159, 52, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:27:\"2019/08/Canon-EOS-6D048.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"Canon-EOS-6D048-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"Canon-EOS-6D048-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:27:\"Canon-EOS-6D048-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"9\";s:6:\"credit\";s:5:\"LzLai\";s:6:\"camera\";s:12:\"Canon EOS 6D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1498325086\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:7:\"0.00625\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(160, 50, '_thumbnail_id', '52'),
(161, 54, '_menu_item_type', 'post_type'),
(162, 54, '_menu_item_menu_item_parent', '0'),
(163, 54, '_menu_item_object_id', '50'),
(164, 54, '_menu_item_object', 'page'),
(165, 54, '_menu_item_target', ''),
(166, 54, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(167, 54, '_menu_item_xfn', ''),
(168, 54, '_menu_item_url', ''),
(170, 55, '_edit_last', '1'),
(171, 55, '_edit_lock', '1565949478:1'),
(172, 56, '_wp_attached_file', '2019/08/Canon-EOS-5D-Mark-III057.jpg'),
(173, 56, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:36:\"2019/08/Canon-EOS-5D-Mark-III057.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III057-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III057-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III057-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"1.6\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:21:\"Canon EOS 5D Mark III\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1505995822\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:5:\"0.008\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(174, 55, '_thumbnail_id', '56'),
(177, 58, '_edit_last', '1'),
(178, 58, '_edit_lock', '1565949569:1'),
(179, 59, '_wp_attached_file', '2019/08/Canon-EOS-5D-Mark-III077.jpg'),
(180, 59, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:36:\"2019/08/Canon-EOS-5D-Mark-III077.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III077-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III077-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:36:\"Canon-EOS-5D-Mark-III077-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"4\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:21:\"Canon EOS 5D Mark III\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"32\";s:3:\"iso\";s:3:\"640\";s:13:\"shutter_speed\";s:17:\"0.016666666666667\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(181, 58, '_thumbnail_id', '59'),
(184, 61, '_edit_last', '1'),
(185, 61, '_edit_lock', '1565949624:1'),
(186, 62, '_wp_attached_file', '2019/08/Canon-EOS-6D180.jpg'),
(187, 62, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:27:\"2019/08/Canon-EOS-6D180.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"Canon-EOS-6D180-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"Canon-EOS-6D180-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:27:\"Canon-EOS-6D180-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"6.3\";s:6:\"credit\";s:3:\"QYZ\";s:6:\"camera\";s:12:\"Canon EOS 6D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1510243257\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"35\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:5:\"0.004\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(188, 61, '_thumbnail_id', '62'),
(191, 64, '_edit_last', '1'),
(192, 64, '_edit_lock', '1565949681:1'),
(193, 65, '_wp_attached_file', '2019/08/Canon-EOS-5D020-1.jpg'),
(194, 65, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:4:\"file\";s:29:\"2019/08/Canon-EOS-5D020-1.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"Canon-EOS-5D020-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"Canon-EOS-5D020-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:29:\"Canon-EOS-5D020-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:29:\"Canon-EOS-5D020-1-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"large-thumbnail\";a:4:{s:4:\"file\";s:30:\"Canon-EOS-5D020-1-1024x400.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"4\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:12:\"Canon EOS 5D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1195411261\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"60\";s:3:\"iso\";s:4:\"1600\";s:13:\"shutter_speed\";s:17:\"0.016666666666667\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(195, 64, '_thumbnail_id', '65'),
(198, 67, '_edit_last', '1'),
(199, 67, '_edit_lock', '1565949741:1'),
(200, 68, '_wp_attached_file', '2019/08/Canon-EOS-6D078.jpg'),
(201, 68, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:27:\"2019/08/Canon-EOS-6D078.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"Canon-EOS-6D078-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"Canon-EOS-6D078-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:27:\"Canon-EOS-6D078-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:2:\"11\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:12:\"Canon EOS 6D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1484146921\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"47\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:6:\"0.0125\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(202, 67, '_thumbnail_id', '68'),
(205, 70, '_edit_last', '1'),
(206, 70, '_edit_lock', '1565950591:1'),
(207, 70, '_thumbnail_id', '28'),
(212, 72, '_edit_lock', '1565954666:1'),
(213, 72, '_wp_trash_meta_status', 'publish'),
(214, 72, '_wp_trash_meta_time', '1565954668'),
(215, 73, '_edit_lock', '1565954680:1'),
(216, 73, '_wp_trash_meta_status', 'publish'),
(217, 73, '_wp_trash_meta_time', '1565954701'),
(218, 74, '_wp_attached_file', '2019/08/Canon-EOS-5D-Mark-II051.jpg'),
(219, 74, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:340;s:4:\"file\";s:35:\"2019/08/Canon-EOS-5D-Mark-II051.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"Canon-EOS-5D-Mark-II051-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"Canon-EOS-5D-Mark-II051-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"small-thumbnail\";a:4:{s:4:\"file\";s:35:\"Canon-EOS-5D-Mark-II051-150x230.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:20:\"Canon EOS 5D Mark II\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1401509883\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:4:\"0.02\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(220, 75, '_edit_lock', '1565957474:1'),
(221, 75, '_wp_trash_meta_status', 'publish'),
(222, 75, '_wp_trash_meta_time', '1565957500'),
(223, 76, '_edit_lock', '1565957562:1'),
(224, 76, '_wp_trash_meta_status', 'publish'),
(225, 76, '_wp_trash_meta_time', '1565957563');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-08-14 14:36:15', '2019-08-14 14:36:15', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2019-08-16 09:04:33', '2019-08-16 09:04:33', '', 0, 'http://localhost/Business/?p=1', 0, 'post', '', 1),
(2, 1, '2019-08-14 14:36:15', '2019-08-14 14:36:15', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://localhost/Business/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2019-08-16 08:46:26', '2019-08-16 08:46:26', '', 0, 'http://localhost/Business/?page_id=2', 0, 'page', '', 0),
(3, 1, '2019-08-14 14:36:15', '2019-08-14 14:36:15', '<h2>Who we are</h2><p>Our website address is: http://localhost/Business.</p><h2>What personal data we collect and why we collect it</h2><h3>Comments</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Media</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>', 'Privacy Policy', '', 'trash', 'closed', 'open', '', 'privacy-policy__trashed', '', '', '2019-08-16 08:46:30', '2019-08-16 08:46:30', '', 0, 'http://localhost/Business/?page_id=3', 0, 'page', '', 0),
(4, 1, '2019-08-14 14:36:40', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-08-14 14:36:40', '0000-00-00 00:00:00', '', 0, 'http://localhost/Business/?p=4', 0, 'post', '', 0),
(5, 1, '2019-08-16 08:44:29', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-08-16 08:44:29', '0000-00-00 00:00:00', '', 0, 'http://localhost/Business/?p=5', 1, 'nav_menu_item', '', 0),
(6, 1, '2019-08-16 08:44:30', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-08-16 08:44:30', '0000-00-00 00:00:00', '', 0, 'http://localhost/Business/?p=6', 1, 'nav_menu_item', '', 0),
(7, 1, '2019-08-16 08:44:48', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-08-16 08:44:48', '0000-00-00 00:00:00', '', 0, 'http://localhost/Business/?p=7', 1, 'nav_menu_item', '', 0),
(8, 1, '2019-08-16 08:44:49', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-08-16 08:44:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/Business/?p=8', 1, 'nav_menu_item', '', 0),
(9, 1, '2019-08-16 08:45:45', '2019-08-16 08:45:45', '{\n    \"nav_menu[-4339142985363345400]\": {\n        \"value\": {\n            \"name\": \"Primary\",\n            \"description\": \"\",\n            \"parent\": 0,\n            \"auto_add\": false\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 08:45:45\"\n    },\n    \"nav_menu_item[-1318301953667852300]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"\",\n            \"menu_item_parent\": 0,\n            \"position\": 1,\n            \"type\": \"custom\",\n            \"title\": \"Home\",\n            \"url\": \"http://localhost/Business\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Home\",\n            \"nav_menu_term_id\": -4339142985363345400,\n            \"_invalid\": false,\n            \"type_label\": \"Custom Link\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 08:45:45\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '094468e6-133a-4260-9189-3da66d300821', '', '', '2019-08-16 08:45:45', '2019-08-16 08:45:45', '', 0, 'http://localhost/Business/2019/08/16/094468e6-133a-4260-9189-3da66d300821/', 0, 'customize_changeset', '', 0),
(10, 1, '2019-08-16 08:45:45', '2019-08-16 08:45:45', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-08-16 09:41:57', '2019-08-16 09:41:57', '', 0, 'http://localhost/Business/2019/08/16/home/', 1, 'nav_menu_item', '', 0),
(11, 1, '2019-08-16 08:46:26', '2019-08-16 08:46:26', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://localhost/Business/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2019-08-16 08:46:26', '2019-08-16 08:46:26', '', 2, 'http://localhost/Business/2019/08/16/2-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2019-08-16 08:46:30', '2019-08-16 08:46:30', '<h2>Who we are</h2><p>Our website address is: http://localhost/Business.</p><h2>What personal data we collect and why we collect it</h2><h3>Comments</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Media</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2019-08-16 08:46:30', '2019-08-16 08:46:30', '', 3, 'http://localhost/Business/2019/08/16/3-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2019-08-16 08:46:42', '2019-08-16 08:46:42', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-08-16 08:46:42', '2019-08-16 08:46:42', '', 0, 'http://localhost/Business/?page_id=13', 0, 'page', '', 0),
(14, 1, '2019-08-16 08:46:42', '2019-08-16 08:46:42', '', 'Home', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2019-08-16 08:46:42', '2019-08-16 08:46:42', '', 13, 'http://localhost/Business/2019/08/16/13-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2019-08-16 08:46:51', '2019-08-16 08:46:51', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2019-08-16 09:16:41', '2019-08-16 09:16:41', '', 0, 'http://localhost/Business/?page_id=15', 0, 'page', '', 0),
(16, 1, '2019-08-16 08:46:51', '2019-08-16 08:46:51', '', 'About', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2019-08-16 08:46:51', '2019-08-16 08:46:51', '', 15, 'http://localhost/Business/2019/08/16/15-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2019-08-16 08:47:01', '2019-08-16 08:47:01', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2019-08-16 08:47:01', '2019-08-16 08:47:01', '', 0, 'http://localhost/Business/?page_id=17', 0, 'page', '', 0),
(18, 1, '2019-08-16 08:47:01', '2019-08-16 08:47:01', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2019-08-16 08:47:01', '2019-08-16 08:47:01', '', 17, 'http://localhost/Business/2019/08/16/17-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2019-08-16 08:47:39', '2019-08-16 08:47:39', ' ', '', '', 'publish', 'closed', 'closed', '', '19', '', '', '2019-08-16 09:41:57', '2019-08-16 09:41:57', '', 0, 'http://localhost/Business/?p=19', 3, 'nav_menu_item', '', 0),
(20, 1, '2019-08-16 08:47:39', '2019-08-16 08:47:39', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2019-08-16 09:41:57', '2019-08-16 09:41:57', '', 0, 'http://localhost/Business/?p=20', 2, 'nav_menu_item', '', 0),
(21, 1, '2019-08-16 08:47:23', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-08-16 08:47:23', '0000-00-00 00:00:00', '', 0, 'http://localhost/Business/?p=21', 1, 'nav_menu_item', '', 0),
(22, 1, '2019-08-16 09:02:23', '2019-08-16 09:02:23', '', 'Canon EOS 5D Mark III039', '', 'inherit', 'open', 'closed', '', 'canon-eos-5d-mark-iii039', '', '', '2019-08-16 09:02:23', '2019-08-16 09:02:23', '', 0, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-III039.jpg', 0, 'attachment', 'image/jpeg', 0),
(23, 1, '2019-08-16 09:04:33', '2019-08-16 09:04:33', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2019-08-16 09:04:33', '2019-08-16 09:04:33', '', 1, 'http://localhost/Business/2019/08/16/1-revision-v1/', 0, 'revision', '', 0),
(24, 1, '2019-08-16 09:05:29', '2019-08-16 09:05:29', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'Laravel', '', 'publish', 'open', 'open', '', 'laravel', '', '', '2019-08-16 09:05:46', '2019-08-16 09:05:46', '', 0, 'http://localhost/Business/?p=24', 0, 'post', '', 1),
(25, 1, '2019-08-16 09:05:24', '2019-08-16 09:05:24', '', 'Canon EOS 5D Mark III101', '', 'inherit', 'open', 'closed', '', 'canon-eos-5d-mark-iii101', '', '', '2019-08-16 09:05:24', '2019-08-16 09:05:24', '', 24, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-III101.jpg', 0, 'attachment', 'image/jpeg', 0),
(26, 1, '2019-08-16 09:05:29', '2019-08-16 09:05:29', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'Laravel', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2019-08-16 09:05:29', '2019-08-16 09:05:29', '', 24, 'http://localhost/Business/2019/08/16/24-revision-v1/', 0, 'revision', '', 0),
(27, 1, '2019-08-16 09:08:02', '2019-08-16 09:08:02', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'Codeigniter', '', 'publish', 'open', 'open', '', 'codeigniter', '', '', '2019-08-16 09:08:02', '2019-08-16 09:08:02', '', 0, 'http://localhost/Business/?p=27', 0, 'post', '', 0),
(28, 1, '2019-08-16 09:07:58', '2019-08-16 09:07:58', '', 'Working at meeting', 'Group of business partners discussing ideas at meeting in office', 'inherit', 'open', 'closed', '', 'working-at-meeting', '', '', '2019-08-16 09:07:58', '2019-08-16 09:07:58', '', 27, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-III169.jpg', 0, 'attachment', 'image/jpeg', 0),
(29, 1, '2019-08-16 09:08:02', '2019-08-16 09:08:02', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'Codeigniter', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2019-08-16 09:08:02', '2019-08-16 09:08:02', '', 27, 'http://localhost/Business/2019/08/16/27-revision-v1/', 0, 'revision', '', 0),
(30, 1, '2019-08-16 09:09:04', '2019-08-16 09:09:04', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'Cake', '', 'publish', 'open', 'open', '', 'cake', '', '', '2019-08-16 09:09:04', '2019-08-16 09:09:04', '', 0, 'http://localhost/Business/?p=30', 0, 'post', '', 1),
(31, 1, '2019-08-16 09:09:01', '2019-08-16 09:09:01', '', 'Canon EOS 5D Mark III111', '', 'inherit', 'open', 'closed', '', 'canon-eos-5d-mark-iii111', '', '', '2019-08-16 09:09:01', '2019-08-16 09:09:01', '', 30, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-III111.jpg', 0, 'attachment', 'image/jpeg', 0),
(32, 1, '2019-08-16 09:09:04', '2019-08-16 09:09:04', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'Cake', '', 'inherit', 'closed', 'closed', '', '30-revision-v1', '', '', '2019-08-16 09:09:04', '2019-08-16 09:09:04', '', 30, 'http://localhost/Business/2019/08/16/30-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2019-08-16 09:10:06', '2019-08-16 09:10:06', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'Gist', '', 'publish', 'open', 'open', '', 'gist', '', '', '2019-08-16 09:10:06', '2019-08-16 09:10:06', '', 0, 'http://localhost/Business/?p=33', 0, 'post', '', 0),
(34, 1, '2019-08-16 09:10:01', '2019-08-16 09:10:01', '', 'Canon EOS 6D090', '', 'inherit', 'open', 'closed', '', 'canon-eos-6d090', '', '', '2019-08-16 09:10:01', '2019-08-16 09:10:01', '', 33, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-6D090.jpg', 0, 'attachment', 'image/jpeg', 0),
(35, 1, '2019-08-16 09:10:06', '2019-08-16 09:10:06', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'Gist', '', 'inherit', 'closed', 'closed', '', '33-revision-v1', '', '', '2019-08-16 09:10:06', '2019-08-16 09:10:06', '', 33, 'http://localhost/Business/2019/08/16/33-revision-v1/', 0, 'revision', '', 0),
(36, 1, '2019-08-16 09:11:32', '2019-08-16 09:11:32', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'The patroitic citizens', '', 'publish', 'open', 'open', '', 'the-patroitic-citizens', '', '', '2019-08-16 09:11:52', '2019-08-16 09:11:52', '', 0, 'http://localhost/Business/?p=36', 0, 'post', '', 0),
(37, 1, '2019-08-16 09:11:19', '2019-08-16 09:11:19', '', 'Two young beautiful girls', 'Two young beautiful girls are walking through the city and listen to music', 'inherit', 'open', 'closed', '', 'two-young-beautiful-girls', '', '', '2019-08-16 09:11:19', '2019-08-16 09:11:19', '', 36, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-III089.jpg', 0, 'attachment', 'image/jpeg', 0),
(38, 1, '2019-08-16 09:11:32', '2019-08-16 09:11:32', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'the patroitic citizens', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2019-08-16 09:11:32', '2019-08-16 09:11:32', '', 36, 'http://localhost/Business/2019/08/16/36-revision-v1/', 0, 'revision', '', 0),
(39, 1, '2019-08-16 09:11:52', '2019-08-16 09:11:52', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'The patroitic citizens', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2019-08-16 09:11:52', '2019-08-16 09:11:52', '', 36, 'http://localhost/Business/2019/08/16/36-revision-v1/', 0, 'revision', '', 0),
(40, 1, '2019-08-16 09:16:37', '2019-08-16 09:16:37', '', 'Canon EOS 5D Mark IV137', '', 'inherit', 'open', 'closed', '', 'canon-eos-5d-mark-iv137', '', '', '2019-08-16 09:16:37', '2019-08-16 09:16:37', '', 15, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-IV137-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(41, 1, '2019-08-16 09:16:41', '2019-08-16 09:16:41', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'About', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2019-08-16 09:16:41', '2019-08-16 09:16:41', '', 15, 'http://localhost/Business/2019/08/16/15-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2019-08-16 09:23:04', '2019-08-16 09:23:04', '', 'Teamwork', 'Large business group gathering to discuss business matters', 'inherit', 'open', 'closed', '', 'teamwork', '', '', '2019-08-16 09:23:04', '2019-08-16 09:23:04', '', 0, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-II124-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(43, 1, '2019-08-16 09:25:29', '2019-08-16 09:25:29', '', 'Two young beautiful girls', 'Two young beautiful girls are walking through the city and listen to music', 'inherit', 'open', 'closed', '', 'two-young-beautiful-girls-2', '', '', '2019-08-16 09:25:29', '2019-08-16 09:25:29', '', 0, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-III089-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(44, 1, '2019-08-16 09:28:30', '2019-08-16 09:28:30', '', 'Family dinner', 'Portrait of young woman and her daughters sitting by dinner table and having meals', 'inherit', 'open', 'closed', '', 'family-dinner', '', '', '2019-08-16 09:28:30', '2019-08-16 09:28:30', '', 0, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-III045-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(45, 1, '2019-08-16 09:34:19', '2019-08-16 09:34:19', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2019-08-16 09:37:33', '2019-08-16 09:37:33', '', 0, 'http://localhost/Business/?page_id=45', 0, 'page', '', 0),
(46, 1, '2019-08-16 09:34:19', '2019-08-16 09:34:19', '', 'contact', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2019-08-16 09:34:19', '2019-08-16 09:34:19', '', 45, 'http://localhost/Business/2019/08/16/45-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2019-08-16 09:34:42', '2019-08-16 09:34:42', ' ', '', '', 'publish', 'closed', 'closed', '', '47', '', '', '2019-08-16 09:41:57', '2019-08-16 09:41:57', '', 0, 'http://localhost/Business/?p=47', 4, 'nav_menu_item', '', 0),
(48, 1, '2019-08-16 09:37:28', '2019-08-16 09:37:28', '', 'Canon EOS 6D085', '', 'inherit', 'open', 'closed', '', 'canon-eos-6d085', '', '', '2019-08-16 09:37:28', '2019-08-16 09:37:28', '', 45, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-6D085-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(49, 1, '2019-08-16 09:37:33', '2019-08-16 09:37:33', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'contact', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2019-08-16 09:37:33', '2019-08-16 09:37:33', '', 45, 'http://localhost/Business/2019/08/16/45-revision-v1/', 0, 'revision', '', 0),
(50, 1, '2019-08-16 09:41:02', '2019-08-16 09:41:02', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'Services', '', 'publish', 'closed', 'closed', '', 'services', '', '', '2019-08-16 09:41:38', '2019-08-16 09:41:38', '', 0, 'http://localhost/Business/?page_id=50', 0, 'page', '', 0),
(51, 1, '2019-08-16 09:41:02', '2019-08-16 09:41:02', '', 'Services', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2019-08-16 09:41:02', '2019-08-16 09:41:02', '', 50, 'http://localhost/Business/2019/08/16/50-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2019-08-16 09:41:27', '2019-08-16 09:41:27', '', 'Canon EOS 6D048', '', 'inherit', 'open', 'closed', '', 'canon-eos-6d048', '', '', '2019-08-16 09:41:27', '2019-08-16 09:41:27', '', 50, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-6D048.jpg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2019-08-16 09:41:38', '2019-08-16 09:41:38', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab.', 'Services', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2019-08-16 09:41:38', '2019-08-16 09:41:38', '', 50, 'http://localhost/Business/2019/08/16/50-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2019-08-16 09:41:57', '2019-08-16 09:41:57', ' ', '', '', 'publish', 'closed', 'closed', '', '54', '', '', '2019-08-16 09:41:57', '2019-08-16 09:41:57', '', 0, 'http://localhost/Business/?p=54', 5, 'nav_menu_item', '', 0),
(55, 1, '2019-08-16 10:00:02', '2019-08-16 10:00:02', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore', 'Globalization', '', 'publish', 'open', 'open', '', 'globalization', '', '', '2019-08-16 10:00:02', '2019-08-16 10:00:02', '', 0, 'http://localhost/Business/?p=55', 0, 'post', '', 0),
(56, 1, '2019-08-16 09:59:58', '2019-08-16 09:59:58', '', 'Canon EOS 5D Mark III057', '', 'inherit', 'open', 'closed', '', 'canon-eos-5d-mark-iii057', '', '', '2019-08-16 09:59:58', '2019-08-16 09:59:58', '', 55, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-III057.jpg', 0, 'attachment', 'image/jpeg', 0),
(57, 1, '2019-08-16 10:00:02', '2019-08-16 10:00:02', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore', 'Globalization', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2019-08-16 10:00:02', '2019-08-16 10:00:02', '', 55, 'http://localhost/Business/2019/08/16/55-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2019-08-16 10:01:31', '2019-08-16 10:01:31', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore', 'Economic Development', '', 'publish', 'open', 'open', '', 'economic-development', '', '', '2019-08-16 10:01:31', '2019-08-16 10:01:31', '', 0, 'http://localhost/Business/?p=58', 0, 'post', '', 0),
(59, 1, '2019-08-16 10:01:25', '2019-08-16 10:01:25', '', 'Canon EOS 5D Mark III077', '', 'inherit', 'open', 'closed', '', 'canon-eos-5d-mark-iii077', '', '', '2019-08-16 10:01:25', '2019-08-16 10:01:25', '', 58, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-III077.jpg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2019-08-16 10:01:31', '2019-08-16 10:01:31', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore', 'Economic Development', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2019-08-16 10:01:31', '2019-08-16 10:01:31', '', 58, 'http://localhost/Business/2019/08/16/58-revision-v1/', 0, 'revision', '', 0),
(61, 1, '2019-08-16 10:02:44', '2019-08-16 10:02:44', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore', 'Congestion in Towns', '', 'publish', 'open', 'open', '', 'congestion-in-towns', '', '', '2019-08-16 10:02:44', '2019-08-16 10:02:44', '', 0, 'http://localhost/Business/?p=61', 0, 'post', '', 0),
(62, 1, '2019-08-16 10:02:39', '2019-08-16 10:02:39', '', 'Canon EOS 6D180', '', 'inherit', 'open', 'closed', '', 'canon-eos-6d180', '', '', '2019-08-16 10:02:39', '2019-08-16 10:02:39', '', 61, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-6D180.jpg', 0, 'attachment', 'image/jpeg', 0),
(63, 1, '2019-08-16 10:02:44', '2019-08-16 10:02:44', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore', 'Congestion in Towns', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2019-08-16 10:02:44', '2019-08-16 10:02:44', '', 61, 'http://localhost/Business/2019/08/16/61-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2019-08-16 10:03:29', '2019-08-16 10:03:29', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore', 'Real World Challenges', '', 'publish', 'open', 'open', '', 'real-world-challenges', '', '', '2019-08-16 10:03:29', '2019-08-16 10:03:29', '', 0, 'http://localhost/Business/?p=64', 0, 'post', '', 0),
(65, 1, '2019-08-16 10:03:25', '2019-08-16 10:03:25', '', 'Canon EOS 5D020', '', 'inherit', 'open', 'closed', '', 'canon-eos-5d020', '', '', '2019-08-16 10:03:25', '2019-08-16 10:03:25', '', 64, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D020-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(66, 1, '2019-08-16 10:03:29', '2019-08-16 10:03:29', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore', 'Real World Challenges', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2019-08-16 10:03:29', '2019-08-16 10:03:29', '', 64, 'http://localhost/Business/2019/08/16/64-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2019-08-16 10:04:41', '2019-08-16 10:04:41', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore', 'Cultural Diversity', '', 'publish', 'open', 'open', '', 'cultural-diversity', '', '', '2019-08-16 10:04:41', '2019-08-16 10:04:41', '', 0, 'http://localhost/Business/?p=67', 0, 'post', '', 0),
(68, 1, '2019-08-16 10:04:33', '2019-08-16 10:04:33', '', 'Canon EOS 6D078', '', 'inherit', 'open', 'closed', '', 'canon-eos-6d078', '', '', '2019-08-16 10:04:33', '2019-08-16 10:04:33', '', 67, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-6D078.jpg', 0, 'attachment', 'image/jpeg', 0),
(69, 1, '2019-08-16 10:04:41', '2019-08-16 10:04:41', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore', 'Cultural Diversity', '', 'inherit', 'closed', 'closed', '', '67-revision-v1', '', '', '2019-08-16 10:04:41', '2019-08-16 10:04:41', '', 67, 'http://localhost/Business/2019/08/16/67-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2019-08-16 10:05:27', '2019-08-16 10:05:27', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore', 'Unemployment', '', 'publish', 'open', 'open', '', 'unemployment', '', '', '2019-08-16 10:05:43', '2019-08-16 10:05:43', '', 0, 'http://localhost/Business/?p=70', 0, 'post', '', 1),
(71, 1, '2019-08-16 10:05:27', '2019-08-16 10:05:27', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore officiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, ab. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, ab iste? Dicta sapiente eius distinctio quo reiciendis laborum inventore', 'Unemployment', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2019-08-16 10:05:27', '2019-08-16 10:05:27', '', 70, 'http://localhost/Business/2019/08/16/70-revision-v1/', 0, 'revision', '', 0),
(72, 1, '2019-08-16 11:24:28', '2019-08-16 11:24:28', '{\n    \"Business::box1_text\": {\n        \"value\": \"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Explicabo aperiam ullam cum eos molestias aliquam in officiis alias nisi atque? Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione, vitae!\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 11:23:25\"\n    },\n    \"Business::box1_icon\": {\n        \"value\": \"book\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 11:23:25\"\n    },\n    \"Business::box2_text\": {\n        \"value\": \"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Explicabo aperiam ullam cum eos molestias aliquam in officiis alias nisi atque? Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione, vitae!\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 11:23:25\"\n    },\n    \"Business::box2_icon\": {\n        \"value\": \"laptop\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 11:23:25\"\n    },\n    \"Business::box3_text\": {\n        \"value\": \"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Explicabo aperiam ullam cum eos molestias aliquam in officiis alias nisi atque? Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione, vitae!\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 11:23:25\"\n    },\n    \"Business::box1_heading\": {\n        \"value\": \"Education\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 11:24:26\"\n    },\n    \"Business::box2_heading\": {\n        \"value\": \"Laptop Repairs\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 11:24:26\"\n    },\n    \"Business::box3_heading\": {\n        \"value\": \"Computer Maintainance\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 11:24:26\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '29a286f9-2486-4259-b259-a695f0fb00b2', '', '', '2019-08-16 11:24:28', '2019-08-16 11:24:28', '', 0, 'http://localhost/Business/?p=72', 0, 'customize_changeset', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(73, 1, '2019-08-16 11:25:01', '2019-08-16 11:25:01', '{\n    \"Business::box3_heading\": {\n        \"value\": \"Computer Maintainance\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 11:25:01\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'b21de6cd-249e-4b61-bd85-2fbc3eee520d', '', '', '2019-08-16 11:25:01', '2019-08-16 11:25:01', '', 0, 'http://localhost/Business/?p=73', 0, 'customize_changeset', '', 0),
(74, 1, '2019-08-16 12:10:11', '2019-08-16 12:10:11', '', 'Canon EOS 5D Mark II051', '', 'inherit', 'open', 'closed', '', 'canon-eos-5d-mark-ii051', '', '', '2019-08-16 12:10:11', '2019-08-16 12:10:11', '', 0, 'http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-II051.jpg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2019-08-16 12:11:39', '2019-08-16 12:11:39', '{\n    \"Business::banner_heading\": {\n        \"value\": \"Youth Empowerment\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 12:11:14\"\n    },\n    \"Business::banner_image\": {\n        \"value\": \"http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-5D-Mark-II051.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 12:11:14\"\n    },\n    \"Business::box1_icon\": {\n        \"value\": \"pen\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 12:11:39\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '6f7a7c93-fa7d-45d3-98c0-97af4797a870', '', '', '2019-08-16 12:11:39', '2019-08-16 12:11:39', '', 0, 'http://localhost/Business/?p=75', 0, 'customize_changeset', '', 0),
(76, 1, '2019-08-16 12:12:43', '2019-08-16 12:12:43', '{\n    \"Business::banner_heading\": {\n        \"value\": \"Business\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 12:12:41\"\n    },\n    \"Business::banner_image\": {\n        \"value\": \"http://localhost/Business/wp-content/uploads/2019/08/Canon-EOS-6D048.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-08-16 12:12:41\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'c76dcafb-0891-433c-8d68-81a5e0ceae9a', '', '', '2019-08-16 12:12:43', '2019-08-16 12:12:43', '', 0, 'http://localhost/Business/?p=76', 0, 'customize_changeset', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Primary', 'primary', 0),
(3, 'Programming', 'programming', 0),
(4, 'Entertainment', 'entertainment', 0),
(5, 'News', 'news', 0),
(6, 'Jobs', 'jobs', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(10, 2, 0),
(19, 2, 0),
(20, 2, 0),
(24, 3, 0),
(27, 3, 0),
(30, 3, 0),
(33, 4, 0),
(36, 4, 0),
(36, 5, 0),
(47, 2, 0),
(54, 2, 0),
(55, 5, 0),
(58, 5, 0),
(61, 4, 0),
(64, 5, 0),
(67, 4, 0),
(70, 6, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 5),
(3, 3, 'category', '', 0, 3),
(4, 4, 'category', '', 0, 4),
(5, 5, 'category', '', 0, 4),
(6, 6, 'category', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'Stephanie'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'true'),
(8, 1, 'admin_color', 'midnight'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'false'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(20, 1, 'wp_user-settings', 'libraryContent=browse&editor=tinymce'),
(21, 1, 'wp_user-settings-time', '1565945061'),
(22, 1, 'nav_menu_recently_edited', '2'),
(23, 1, 'closedpostboxes_post', 'a:1:{i:0;s:16:\"tagsdiv-post_tag\";}'),
(24, 1, 'metaboxhidden_post', 'a:6:{i:0;s:11:\"postexcerpt\";i:1;s:13:\"trackbacksdiv\";i:2;s:10:\"postcustom\";i:3;s:16:\"commentstatusdiv\";i:4;s:7:\"slugdiv\";i:5;s:9:\"authordiv\";}'),
(25, 1, 'meta-box-order_post', 'a:3:{s:4:\"side\";s:51:\"submitdiv,categorydiv,tagsdiv-post_tag,postimagediv\";s:6:\"normal\";s:71:\"postexcerpt,trackbacksdiv,postcustom,commentstatusdiv,slugdiv,authordiv\";s:8:\"advanced\";s:0:\"\";}'),
(26, 1, 'screen_layout_post', '2'),
(28, 1, 'session_tokens', 'a:1:{s:64:\"21862aa7d7aa6774da175c84eee73294feeacb97ea0cfb81cc646e820b9ac708\";a:4:{s:10:\"expiration\";i:1567166463;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36\";s:5:\"login\";i:1565956863;}}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'Stephanie', '$P$BCoQr.hNh8UK3X.FBupitRB4gzvt.c0', 'stephanie', 'dinayenstephanie047@gmail.com', '', '2019-08-14 14:36:14', '', 0, 'Stephanie');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=226;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
